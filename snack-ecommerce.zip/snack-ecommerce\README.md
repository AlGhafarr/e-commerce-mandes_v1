# Snack E-Commerce Platform

Platform e-commerce modern untuk toko cemilan.

## Quick Start

```bash
# Install dependencies
npm install

# Setup environment
copy .env.example .env.local
# Edit .env.local dengan credentials Anda

# Setup database
npx prisma generate
npx prisma db push

# Run development server
npm run dev
```

Access at: http://localhost:3000
